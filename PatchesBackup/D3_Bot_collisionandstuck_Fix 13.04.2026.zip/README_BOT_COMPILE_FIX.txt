D3 bot compile-fix patch

What was fixed:
- Removed the invalid top-level injected methods that caused CS0106 in BotManager.cs
- Applied no-collision properly inside BotManager as a real class method
- Set bot CollFlags = 0 and broadcast ACDCollFlagsMessage so players can walk through bots
- Switched bot movement to MoveToPointWithPathfindAction in BotBrain
- Added progress tracking / stuck recovery in BotBrain so bots recover if they stop moving after teleports or map transitions

Files included:
- src/DiIiS-NA/D3-GameServer/GSSystem/BotSystem/BotManager.cs
- src/DiIiS-NA/D3-GameServer/GSSystem/AISystem/Brains/BotBrain.cs
