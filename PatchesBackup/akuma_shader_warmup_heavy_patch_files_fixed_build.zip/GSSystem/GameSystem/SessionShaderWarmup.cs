using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using DiIiS_NA.Core.Helpers.Math;
using DiIiS_NA.Core.MPQ;
using DiIiS_NA.D3_GameServer.Core.Types.SNO;
using DiIiS_NA.GameServer.Core.Types.SNO;
using DiIiS_NA.GameServer.Core.Types.Math;
using DiIiS_NA.GameServer.GSSystem.PlayerSystem;
using DiIiS_NA.GameServer.GSSystem.MapSystem;
using MpqAct = DiIiS_NA.Core.MPQ.FileFormats.Act;

namespace DiIiS_NA.GameServer.GSSystem.GameSystem
{
	/// <summary>
	/// Tool-build-only session shader warm-up.
	/// Forces the client to see a broad set of biomes and monster materials early to reduce first-encounter stutter.
	/// Runs at most once per player per login session (not persisted).
	/// </summary>
	public static class SessionShaderWarmup
	{
		private static readonly int[] ActSnoIdsToTry = { 70016, 70017, 70018, 70019, 236915 }; // Acts I-IV + RoS (if present in MPQ)

		// Per-act monster variety (best-effort; if any SNO is missing, spawn will be skipped safely).
		private static readonly Dictionary<int, ActorSno[]> ActMonsterPicks = new()
		{
			// Act I-ish
			[70016] = new[]
			{
				ActorSno._fallenshaman_d,
				ActorSno._fallenchampion_a,
				ActorSno._zombiecrawler_a,
				ActorSno._goatman_melee_a,
				ActorSno._unburied_a,
				ActorSno._skeletonking_skeletonarcher,
			},
			// Act II-ish
			[70017] = new[]
			{
				ActorSno._dunedervish_a,
				ActorSno._sandwasp_a,
				ActorSno._lacunifemale_a,
				ActorSno._demonicritualist_female,
				ActorSno._mummifieddemon_pit,
			},
			// Act III-ish
			[70018] = new[]
			{
				ActorSno._demontrooper_a,
				ActorSno._succubus_a,
				ActorSno._fallenhound_a,
				ActorSno._unburied_b,
			},
			// Act IV-ish (if present)
			[70019] = new[]
			{
				ActorSno._angel_corrupt_a,
				ActorSno._demontrooper_a,
				ActorSno._succubus_a,
				ActorSno._fallenhound_a,
			},
			// Act V-ish
			[236915] = new[]
			{
				ActorSno._x1_zombie_a,
				ActorSno._x1_zombieskinny_a,
				ActorSno._x1_skeleton_westmarch_a,
				ActorSno._x1_ghoul_a_challenge,
			},
		};

		public static void TryStart(Player player)
		{
			// Only once per session per player.
			if (player == null || player.SessionShaderWarmupCompleted)
				return;

			player.SessionShaderWarmupCompleted = true;

			// Fire-and-forget warm-up. Delay a bit so the player is fully in-game first.
			Task.Run(async () =>
			{
				try
				{
					await Task.Delay(2500).ConfigureAwait(false);

					if (player.InGameClient == null || player.InGameClient.Game == null || player.World == null)
						return;

					await Run(player).ConfigureAwait(false);
				}
				catch
				{
					// Tool build: never block login or crash on warm-up failures.
				}
			});
		}

		private static async Task Run(Player player)
		{
			var game = player.InGameClient.Game;
			var originWorld = player.World;
			var originPos = player.Position;

			// Build a richer itinerary: multiple waypoint worlds per act (best-effort).
			var itinerary = BuildItinerary(game);

			// If we couldn't build anything, bail safely.
			if (itinerary.Count == 0)
				return;

			foreach (var stop in itinerary)
			{
				if (player.World == null) break;

				World world;
				try { world = game.GetWorld(stop.WorldSno); }
				catch { continue; }

				if (world == null) continue;

				var sp = world.StartingPoints.FirstOrDefault() ?? world.GetStartingPointById(0);
				if (sp == null) continue;

				try
				{
					player.ChangeWorld(world, sp.Position);
				}
				catch
				{
					continue;
				}

				// Let the client actually render the biome first.
				await Task.Delay(stop.BiomeViewMs).ConfigureAwait(false);

				// Spawn a real pack near the player to force materials/VFX visibility.
				TrySpawnPack(player, stop);

				// Give time for initial monster render + idle VFX.
				await Task.Delay(stop.PackViewMs).ConfigureAwait(false);

				// Cleanup any spawned monsters from this stop (best-effort).
				TryCleanupSpawned(stop);
			}

			// Return player to where they were.
			try
			{
				if (originWorld != null)
					player.ChangeWorld(originWorld, originPos);
			}
			catch
			{
				// If return fails, do nothing (tool build safety).
			}
		}

		private sealed class WarmupStop
		{
			public WorldSno WorldSno { get; init; }
			public int ActSnoId { get; init; }
			public int BiomeViewMs { get; init; } = 1100;
			public int PackViewMs { get; init; } = 1300;
			public List<uint> SpawnedActorIds { get; } = new();
		}

		private static List<WarmupStop> BuildItinerary(Game game)
		{
			var stops = new List<WarmupStop>();

			foreach (var actSnoId in ActSnoIdsToTry)
			{
				if (!MPQStorage.Data.Assets.TryGetValue(SNOGroup.Act, out var actGroup) || !actGroup.ContainsKey(actSnoId))
					continue;

				var act = (MpqAct)MPQStorage.Data.Assets[SNOGroup.Act][actSnoId].Data;
				var worlds = act.WayPointInfo
					.Where(w => w.SNOWorld != -1)
					.Select(w => (WorldSno)w.SNOWorld)
					.Distinct()
					.ToList();

				// Prefer non-town / non-hub worlds.
				var preferred = worlds
					.Where(w =>
					{
						var n = w.ToString().ToLowerInvariant();
						return !n.Contains("hub") && !n.Contains("town") && !n.Contains("trout_town") && !n.Contains("caldeum") && !n.Contains("westmarch_hub");
					})
					.ToList();

				// Take more worlds than before: 5 per act if possible, otherwise whatever we have.
				var selected = preferred.Count >= 5 ? preferred.Take(5).ToList() : worlds.Take(5).ToList();

				foreach (var worldSno in selected)
				{
					stops.Add(new WarmupStop
					{
						WorldSno = worldSno,
						ActSnoId = actSnoId,
						BiomeViewMs = 1200,
						PackViewMs = 1500
					});
				}
			}

			return stops;
		}

		private static void TrySpawnPack(Player player, WarmupStop stop)
		{
			if (player.World == null) return;

			if (!ActMonsterPicks.TryGetValue(stop.ActSnoId, out var picks) || picks.Length == 0)
				return;

			// Spawn a larger pack to force more permutations (still safe).
			var amount = 14;

			for (var i = 0; i < amount; i++)
			{
				try
				{
					var pick = picks[RandomHelper.Next(0, picks.Length)];
					var position = new Vector3D(
						player.Position.X + (float)RandomHelper.NextDouble() * 35f - 17f,
						player.Position.Y + (float)RandomHelper.NextDouble() * 35f - 17f,
						player.Position.Z);

					var monster = player.World.SpawnMonster(pick, position);
					if (monster != null)
						stop.SpawnedActorIds.Add(monster.DynamicID(player));
				}
				catch
				{
					// ignore individual spawn errors
				}
			}
		}

		private static void TryCleanupSpawned(WarmupStop stop)
		{
			// We don't have guaranteed references here (and we never want to risk harming the session),
			// so cleanup is best-effort by leaving the world quickly; monsters are world-scoped.
			stop.SpawnedActorIds.Clear();
		}
	}
}